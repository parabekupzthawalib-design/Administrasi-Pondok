###################
ARTERI : Arsip Elektronik Terintegrasi
###################

ARTERI adalah aplikasi pengelolaan arsip elektronik berbasis web. Bertujuan untuk mempermudah pengelolaan arsip 

*******************
Release Information
*******************
Download arteri `di sini
<https://github.com/dicarve/arteri/releases>`_ .

This repo contains in-development code for future releases. To download the
latest stable release please visit the `Link
<https://github.com/dicarve/arteri>`_ page.


*******************
Server Requirements
*******************

PHP version 5.5 or newer is recommended.

Arteri works with PHP version 5.5.x.

************
Installation
************

There are no installation guideline at this moment

*******
License
*******

Arteri is licensed under GNU General Public License version 3
